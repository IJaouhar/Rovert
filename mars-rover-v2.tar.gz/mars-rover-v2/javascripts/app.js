// Rover Object Goes Here
// ======================
var direction = ["N","E","S","W"];
var go = "0";
var contador = 0;
var x = 0;
var y = 0;
var travelLog = [];
// ======================
function turnRight(rover){
    if(contador < 3 && contador >= 0) {
      alert(direction[(contador+1)]);
      contador++;
    } else {
      contador = 0;
      alert(direction[contador]);
    }
  console.log("Rover turned right 90 degrees!");
}

function turnLeft(rover){
    if(contador > 0) {
      alert(direction[contador]);
      contador--;
    } else {
      contador = 3;
      alert(direction[(contador)]);
      contador--;
    }
  console.log("Rover turned left 90 degrees!");
}

function moveForward(rover){
  if(direction[contador]=="N"){
    if(y>0){
      y-=50;
      travelLog.push(x,y);
      console.log(travelLog[travelLog.length-1]);
    }
    robot.style.top = y + "px";
    contador = 0;
  }
  if(direction[contador]=="E"){
    if(x<500){
      x+=50;
    }
    robot.style.left = x + "px";
    contador = 1;
  }
  if(direction[contador]=="S"){
    if(y<500){
      y+=50;
    }
    robot.style.top = y + "px";
    contador = 2;
  }
  if(direction[contador]=="W"){
    if(x>0){
      x-=50;
    }
    robot.style.left = x + "px";
    contador = 3;
  }
  console.log("moveForward was called")
  travelLog.push({
    x: x,
    y: y
  });
  for (var j=0; j<travelLog.length; j++){
    console.log(travelLog[j]);
  }
}

function Rovertdo(command){
  var contador2 = command.length;
  for (var i = 0; i<contador2;i++){
    var letter = command[i];
    if(letter==="r"){
      turnRight ();
      console.log(i);
    }
    if (letter==="l") {
      turnLeft ();
      console.log(i);
      
    }
    if (letter==="f") {
      moveForward ();
      console.log(i);
      
    }
  console.log("Command was " + letter);
  }
  travelLog.push({
    x: x,
    y: y
  });
  for (var j=0; j<travelLog.length; j++){
    console.log(travelLog[j]);
  }
}

